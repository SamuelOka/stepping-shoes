
  # Single Page Shoe Catalog

  This is a code bundle for Single Page Shoe Catalog. The original project is available at https://www.figma.com/design/dHkpXtZnmuUZqfB3cR23dZ/Single-Page-Shoe-Catalog.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  